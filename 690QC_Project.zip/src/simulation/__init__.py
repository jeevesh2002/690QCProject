import logging, os
level = os.getenv('QNET_LOG', 'INFO').upper()
# logging.basicConfig(level=level,
#                     format='%(levelname).1s %(name)s │ %(message)s')
